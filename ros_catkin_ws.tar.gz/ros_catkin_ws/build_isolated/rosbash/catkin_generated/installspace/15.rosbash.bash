# generated from rosbash/env-hooks/15.rosbash.bash.em

if [ -z "$CATKIN_ENV_HOOK_WORKSPACE" ]; then
  CATKIN_ENV_HOOK_WORKSPACE="/root/ros_catkin_ws/install_isolated"
fi
. "$CATKIN_ENV_HOOK_WORKSPACE/share/rosbash/rosbash"
