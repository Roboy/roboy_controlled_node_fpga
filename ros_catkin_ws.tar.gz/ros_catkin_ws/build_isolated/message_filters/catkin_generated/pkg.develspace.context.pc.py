# generated from catkin/cmake/template/pkg.context.pc.in
CATKIN_PACKAGE_PREFIX = ""
PROJECT_PKG_CONFIG_INCLUDE_DIRS = "/root/ros_catkin_ws/src/ros_comm/message_filters/include".split(';') if "/root/ros_catkin_ws/src/ros_comm/message_filters/include" != "" else []
PROJECT_CATKIN_DEPENDS = "roscpp;xmlrpcpp;rosconsole".replace(';', ' ')
PKG_CONFIG_LIBRARIES_WITH_PREFIX = "-lmessage_filters".split(';') if "-lmessage_filters" != "" else []
PROJECT_NAME = "message_filters"
PROJECT_SPACE_DIR = "/root/ros_catkin_ws/devel_isolated/message_filters"
PROJECT_VERSION = "1.12.7"
