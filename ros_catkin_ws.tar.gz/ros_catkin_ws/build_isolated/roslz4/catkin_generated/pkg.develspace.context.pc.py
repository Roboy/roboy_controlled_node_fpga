# generated from catkin/cmake/template/pkg.context.pc.in
CATKIN_PACKAGE_PREFIX = ""
PROJECT_PKG_CONFIG_INCLUDE_DIRS = "/root/ros_catkin_ws/src/ros_comm/roslz4/include;/usr/include".split(';') if "/root/ros_catkin_ws/src/ros_comm/roslz4/include;/usr/include" != "" else []
PROJECT_CATKIN_DEPENDS = "".replace(';', ' ')
PKG_CONFIG_LIBRARIES_WITH_PREFIX = "-lroslz4;-l:/usr/lib/liblz4.so".split(';') if "-lroslz4;-l:/usr/lib/liblz4.so" != "" else []
PROJECT_NAME = "roslz4"
PROJECT_SPACE_DIR = "/root/ros_catkin_ws/devel_isolated/roslz4"
PROJECT_VERSION = "1.12.7"
