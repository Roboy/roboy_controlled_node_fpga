# generated from catkin/cmake/template/cfg-extras.context.py.in
DEVELSPACE = 'FALSE' == 'TRUE'
INSTALLSPACE = 'TRUE' == 'TRUE'

CATKIN_DEVEL_PREFIX = '/root/ros_catkin_ws/devel_isolated/roslaunch'

CATKIN_GLOBAL_BIN_DESTINATION = 'bin'
CATKIN_GLOBAL_ETC_DESTINATION = 'etc'
CATKIN_GLOBAL_INCLUDE_DESTINATION = 'include'
CATKIN_GLOBAL_LIB_DESTINATION = 'lib'
CATKIN_GLOBAL_LIBEXEC_DESTINATION = 'lib'
CATKIN_GLOBAL_PYTHON_DESTINATION = 'lib/python2.7/dist-packages'
CATKIN_GLOBAL_SHARE_DESTINATION = 'share'

CATKIN_PACKAGE_BIN_DESTINATION = 'lib/roslaunch'
CATKIN_PACKAGE_ETC_DESTINATION = 'etc/roslaunch'
CATKIN_PACKAGE_INCLUDE_DESTINATION = 'include/roslaunch'
CATKIN_PACKAGE_LIB_DESTINATION = 'lib'
CATKIN_PACKAGE_LIBEXEC_DESTINATION = ''
CATKIN_PACKAGE_PYTHON_DESTINATION = 'lib/python2.7/dist-packages/roslaunch'
CATKIN_PACKAGE_SHARE_DESTINATION = 'share/roslaunch'

CMAKE_BINARY_DIR = '/root/ros_catkin_ws/build_isolated/roslaunch'
CMAKE_CURRENT_BINARY_DIR = '/root/ros_catkin_ws/build_isolated/roslaunch'
CMAKE_CURRENT_SOURCE_DIR = '/root/ros_catkin_ws/src/ros_comm/roslaunch'
CMAKE_INSTALL_PREFIX = '/root/ros_catkin_ws/install_isolated'
CMAKE_SOURCE_DIR = '/root/ros_catkin_ws/src/ros_comm/roslaunch'

PKG_CMAKE_DIR = '${roslaunch_DIR}'

PROJECT_NAME = 'roslaunch'
PROJECT_BINARY_DIR = '/root/ros_catkin_ws/build_isolated/roslaunch'
PROJECT_SOURCE_DIR = '/root/ros_catkin_ws/src/ros_comm/roslaunch'
