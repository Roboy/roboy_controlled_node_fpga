# generated from catkin/cmake/template/pkg.context.pc.in
CATKIN_PACKAGE_PREFIX = ""
PROJECT_PKG_CONFIG_INCLUDE_DIRS = "/root/ros_catkin_ws/install_isolated/include;/usr/local/include".split(';') if "/root/ros_catkin_ws/install_isolated/include;/usr/local/include" != "" else []
PROJECT_CATKIN_DEPENDS = "".replace(';', ' ')
PKG_CONFIG_LIBRARIES_WITH_PREFIX = "-l:/usr/local/lib/libboost_system.so;-l:/usr/local/lib/libboost_thread.so;-l:/usr/local/lib/libboost_chrono.so;-l:/usr/local/lib/libboost_date_time.so;-l:/usr/local/lib/libboost_atomic.so".split(';') if "-l:/usr/local/lib/libboost_system.so;-l:/usr/local/lib/libboost_thread.so;-l:/usr/local/lib/libboost_chrono.so;-l:/usr/local/lib/libboost_date_time.so;-l:/usr/local/lib/libboost_atomic.so" != "" else []
PROJECT_NAME = "rostest"
PROJECT_SPACE_DIR = "/root/ros_catkin_ws/install_isolated"
PROJECT_VERSION = "1.12.7"
