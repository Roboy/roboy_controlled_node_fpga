#!/usr/bin/env sh
# generated from catkin/python/catkin/environment_cache.py

# based on a snapshot of the environment before and after calling the setup script
# it emulates the modifications of the setup script without recurring computations

# new environment variables
export ROSLISP_PACKAGE_DIRECTORIES="/root/ros_catkin_ws/devel_isolated/roslisp/share/common-lisp"

# modified environment variables
export CMAKE_PREFIX_PATH="/root/ros_catkin_ws/devel_isolated/roslisp:$CMAKE_PREFIX_PATH"
export LD_LIBRARY_PATH="/root/ros_catkin_ws/devel_isolated/roslisp/lib:$LD_LIBRARY_PATH"
export PKG_CONFIG_PATH="/root/ros_catkin_ws/devel_isolated/roslisp/lib/pkgconfig:$PKG_CONFIG_PATH"