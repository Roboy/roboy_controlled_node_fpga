# generated from catkin/cmake/template/pkg.context.pc.in
CATKIN_PACKAGE_PREFIX = ""
PROJECT_PKG_CONFIG_INCLUDE_DIRS = "/root/ros_catkin_ws/src/ros_comm/rosconsole/include;/usr/local/include".split(';') if "/root/ros_catkin_ws/src/ros_comm/rosconsole/include;/usr/local/include" != "" else []
PROJECT_CATKIN_DEPENDS = "cpp_common;rostime".replace(';', ' ')
PKG_CONFIG_LIBRARIES_WITH_PREFIX = "-lrosconsole;-lrosconsole_print;-lrosconsole_backend_interface;-l:/usr/local/lib/libboost_regex.so;-l:/usr/local/lib/libboost_system.so;-l:/usr/local/lib/libboost_thread.so;-l:/usr/local/lib/libboost_chrono.so;-l:/usr/local/lib/libboost_date_time.so;-l:/usr/local/lib/libboost_atomic.so".split(';') if "-lrosconsole;-lrosconsole_print;-lrosconsole_backend_interface;-l:/usr/local/lib/libboost_regex.so;-l:/usr/local/lib/libboost_system.so;-l:/usr/local/lib/libboost_thread.so;-l:/usr/local/lib/libboost_chrono.so;-l:/usr/local/lib/libboost_date_time.so;-l:/usr/local/lib/libboost_atomic.so" != "" else []
PROJECT_NAME = "rosconsole"
PROJECT_SPACE_DIR = "/root/ros_catkin_ws/devel_isolated/rosconsole"
PROJECT_VERSION = "1.12.7"
