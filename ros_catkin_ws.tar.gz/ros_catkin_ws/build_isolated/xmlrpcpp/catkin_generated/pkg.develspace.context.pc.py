# generated from catkin/cmake/template/pkg.context.pc.in
CATKIN_PACKAGE_PREFIX = ""
PROJECT_PKG_CONFIG_INCLUDE_DIRS = "/root/ros_catkin_ws/src/ros_comm/xmlrpcpp/include".split(';') if "/root/ros_catkin_ws/src/ros_comm/xmlrpcpp/include" != "" else []
PROJECT_CATKIN_DEPENDS = "cpp_common".replace(';', ' ')
PKG_CONFIG_LIBRARIES_WITH_PREFIX = "-lxmlrpcpp".split(';') if "-lxmlrpcpp" != "" else []
PROJECT_NAME = "xmlrpcpp"
PROJECT_SPACE_DIR = "/root/ros_catkin_ws/devel_isolated/xmlrpcpp"
PROJECT_VERSION = "1.12.7"
