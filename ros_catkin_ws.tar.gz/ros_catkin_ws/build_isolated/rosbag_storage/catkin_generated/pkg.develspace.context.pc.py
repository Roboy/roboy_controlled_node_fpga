# generated from catkin/cmake/template/pkg.context.pc.in
CATKIN_PACKAGE_PREFIX = ""
PROJECT_PKG_CONFIG_INCLUDE_DIRS = "/root/ros_catkin_ws/src/ros_comm/rosbag_storage/include;/usr/local/include".split(';') if "/root/ros_catkin_ws/src/ros_comm/rosbag_storage/include;/usr/local/include" != "" else []
PROJECT_CATKIN_DEPENDS = "roslz4".replace(';', ' ')
PKG_CONFIG_LIBRARIES_WITH_PREFIX = "-lrosbag_storage;-l:/usr/local/lib/libconsole_bridge.so;-l:/usr/local/lib/libboost_date_time.so;-l:/usr/local/lib/libboost_filesystem.so;-l:/usr/local/lib/libboost_program_options.so;-l:/usr/local/lib/libboost_regex.so;-l:/usr/local/lib/libboost_system.so".split(';') if "-lrosbag_storage;-l:/usr/local/lib/libconsole_bridge.so;-l:/usr/local/lib/libboost_date_time.so;-l:/usr/local/lib/libboost_filesystem.so;-l:/usr/local/lib/libboost_program_options.so;-l:/usr/local/lib/libboost_regex.so;-l:/usr/local/lib/libboost_system.so" != "" else []
PROJECT_NAME = "rosbag_storage"
PROJECT_SPACE_DIR = "/root/ros_catkin_ws/devel_isolated/rosbag_storage"
PROJECT_VERSION = "1.12.7"
