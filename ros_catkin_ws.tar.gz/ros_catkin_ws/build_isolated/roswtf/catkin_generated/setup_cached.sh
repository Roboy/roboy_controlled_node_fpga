#!/usr/bin/env sh
# generated from catkin/python/catkin/environment_cache.py

# based on a snapshot of the environment before and after calling the setup script
# it emulates the modifications of the setup script without recurring computations

# new environment variables

# modified environment variables
export CMAKE_PREFIX_PATH="/root/ros_catkin_ws/devel_isolated/roswtf:$CMAKE_PREFIX_PATH"
export ROSLISP_PACKAGE_DIRECTORIES="/root/ros_catkin_ws/devel_isolated/roswtf/share/common-lisp"
export ROS_PACKAGE_PATH="/root/ros_catkin_ws/src/ros_comm/roswtf:$ROS_PACKAGE_PATH"