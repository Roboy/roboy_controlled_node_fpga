# generated from catkin/cmake/template/pkg.context.pc.in
CATKIN_PACKAGE_PREFIX = ""
PROJECT_PKG_CONFIG_INCLUDE_DIRS = "/root/ros_catkin_ws/install_isolated/include".split(';') if "/root/ros_catkin_ws/install_isolated/include" != "" else []
PROJECT_CATKIN_DEPENDS = "rospack".replace(';', ' ')
PKG_CONFIG_LIBRARIES_WITH_PREFIX = "-lroslib".split(';') if "-lroslib" != "" else []
PROJECT_NAME = "roslib"
PROJECT_SPACE_DIR = "/root/ros_catkin_ws/install_isolated"
PROJECT_VERSION = "1.13.5"
